package com.SRP.SOES;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoesApplication.class, args);
		System.out.println("SOES Project Is Working.........");
	}

}
